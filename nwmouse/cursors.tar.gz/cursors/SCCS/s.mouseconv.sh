h28320
s 00011/00000/00000
d D 1.1 04/03/09 18:28:12 uholld1 1 0
c date and time created 04/03/09 18:28:12 by uholld1
e
u
U
f e 0
t
T
I 1
#!/bin/bash
for i in *.tga
do
cfgname=`echo $i | sed -e 's/tga$/cfg/g'`
pngname=`echo $i | sed -e 's/tga$/png/g'`
curname=`echo $i | sed -e 's/.tga$//g'`

echo $cfgname $pngname $curname
convert $i $pngname
xcursorgen $cfgname $curname
done
E 1
