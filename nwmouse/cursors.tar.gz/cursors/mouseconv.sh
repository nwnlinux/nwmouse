#!/bin/bash
for i in *.tga
do
cfgname=`echo $i | sed -e 's/tga$/cfg/g'`
pngname=`echo $i | sed -e 's/tga$/png/g'`
curname=`echo $i | sed -e 's/.tga$//g'`

echo $cfgname $pngname $curname
convert $i $pngname
xcursorgen $cfgname $curname
done
